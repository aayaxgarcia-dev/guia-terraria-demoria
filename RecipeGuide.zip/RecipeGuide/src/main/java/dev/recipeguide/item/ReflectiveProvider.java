package dev.recipeguide.item;

import org.bukkit.Bukkit;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Optional;
import java.util.logging.Logger;

/**
 * Proveedor genérico que llama por reflexión al método "item -> id" de la API de otro plugin
 * (Oraxen, Nexo, CraftEngine...). Así no hace falta compilar contra sus jars y, si el
 * nombre de un método cambia, solo se desactiva ese proveedor.
 */
public final class ReflectiveProvider implements ItemProvider {

    private final Logger log;
    private final String prefix;
    private final String pluginName;
    private final String className;
    private final String methodName;

    private Method method;
    private Object target;
    private boolean broken;

    public ReflectiveProvider(Logger log, String prefix, String pluginName, String className, String methodName) {
        this.log = log;
        this.prefix = prefix;
        this.pluginName = pluginName;
        this.className = className;
        this.methodName = methodName;
    }

    @Override
    public String idOf(ItemStack stack) {
        if (broken) {
            return null;
        }
        Plugin plugin = Bukkit.getPluginManager().getPlugin(pluginName);
        if (plugin == null || !plugin.isEnabled()) {
            return null; // aún no está cargado: se reintenta luego
        }
        try {
            if (method == null) {
                Class<?> api = Class.forName(className, true, plugin.getClass().getClassLoader());
                method = api.getMethod(methodName, ItemStack.class);
                // Si es un "object" de Kotlin sin @JvmStatic, hay que usar INSTANCE.
                target = Modifier.isStatic(method.getModifiers()) ? null : api.getField("INSTANCE").get(null);
            }
            Object result = method.invoke(target, stack);
            if (result instanceof Optional<?> optional) {
                result = optional.orElse(null);
            }
            if (result == null) {
                return null;
            }
            String text = result.toString();
            return text.isEmpty() ? null : prefix + ":" + text;
        } catch (InvocationTargetException e) {
            return null; // la API falló con este item concreto; no desactivar todo el proveedor
        } catch (ReflectiveOperationException | LinkageError e) {
            broken = true;
            log.warning("No pude usar la API de " + pluginName + " (" + className + "#" + methodName
                    + "): " + e + ". Reviso items de ese plugin con la huella genérica.");
            return null;
        }
    }
}
