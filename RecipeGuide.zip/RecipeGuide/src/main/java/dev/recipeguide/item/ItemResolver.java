package dev.recipeguide.item;

import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;

/**
 * Convierte un ItemStack en una clave de identidad. Prueba los proveedores en orden;
 * si ninguno lo reconoce, usa el material vanilla ("minecraft:paper").
 */
public final class ItemResolver {

    private final List<ItemProvider> providers = new ArrayList<>();

    public void add(ItemProvider provider) {
        providers.add(provider);
    }

    public String resolve(ItemStack stack) {
        if (stack == null || stack.getType().isAir()) {
            return null;
        }
        for (ItemProvider provider : providers) {
            try {
                String id = provider.idOf(stack);
                if (id != null && !id.isBlank()) {
                    return id;
                }
            } catch (Throwable ignored) {
                // un proveedor roto nunca debe tumbar la guía
            }
        }
        return stack.getType().getKey().toString();
    }

    public static boolean isCustom(String key) {
        return !key.startsWith("minecraft:");
    }
}
