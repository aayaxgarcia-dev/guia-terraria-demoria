package dev.recipeguide.item;

import org.bukkit.inventory.ItemStack;

/** Reconoce items de un plugin concreto y devuelve su id (o null si no es suyo). */
public interface ItemProvider {

    /** @return id única del item, por ejemplo "oraxen:moneda_plata", o null si no lo reconoce. */
    String idOf(ItemStack stack);
}
