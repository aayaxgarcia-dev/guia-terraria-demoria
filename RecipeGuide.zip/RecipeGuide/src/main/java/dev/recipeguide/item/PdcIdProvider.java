package dev.recipeguide.item;

import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.List;

/** Lee la id de un item desde claves PDC (STRING) configuradas, ideal para tus propios plugins. */
public final class PdcIdProvider implements ItemProvider {

    private final List<NamespacedKey> keys = new ArrayList<>();

    public PdcIdProvider(List<String> rawKeys) {
        for (String raw : rawKeys) {
            NamespacedKey key = NamespacedKey.fromString(raw);
            if (key != null) {
                keys.add(key);
            }
        }
    }

    @Override
    public String idOf(ItemStack stack) {
        if (keys.isEmpty()) {
            return null;
        }
        PersistentDataContainer pdc = stack.getPersistentDataContainer();
        for (NamespacedKey key : keys) {
            if (pdc.has(key, PersistentDataType.STRING)) {
                String value = pdc.get(key, PersistentDataType.STRING);
                if (value != null && !value.isEmpty()) {
                    return key.getNamespace() + ":" + value;
                }
            }
        }
        return null;
    }
}
