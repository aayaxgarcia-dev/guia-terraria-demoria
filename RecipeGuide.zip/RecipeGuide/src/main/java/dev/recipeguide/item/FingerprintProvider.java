package dev.recipeguide.item;

import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.components.CustomModelDataComponent;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Último recurso para items custom que ningún proveedor reconoció (datapacks, plugins
 * desconocidos): crea una id estable a partir de item_model, custom_model_data y las
 * claves PDC del item. Un item vanilla "limpio" devuelve null.
 */
public final class FingerprintProvider implements ItemProvider {

    @Override
    public String idOf(ItemStack stack) {
        ItemMeta meta = stack.getItemMeta();
        if (meta == null) {
            return null;
        }
        StringBuilder sb = new StringBuilder();

        if (meta.hasItemModel()) {
            sb.append("model=").append(meta.getItemModel()).append(';');
        }
        if (meta.hasCustomModelDataComponent()) {
            CustomModelDataComponent cmd = meta.getCustomModelDataComponent();
            sb.append("cmd=").append(cmd.getFloats()).append(cmd.getStrings())
                    .append(cmd.getFlags()).append(cmd.getColors()).append(';');
        }

        PersistentDataContainer pdc = meta.getPersistentDataContainer();
        List<NamespacedKey> pdcKeys = new ArrayList<>(pdc.getKeys());
        pdcKeys.sort(Comparator.comparing(NamespacedKey::toString));
        for (NamespacedKey key : pdcKeys) {
            sb.append(key);
            // solo los valores String (ids); los números suelen ser contadores que cambian
            if (pdc.has(key, PersistentDataType.STRING)) {
                sb.append('=').append(pdc.get(key, PersistentDataType.STRING));
            }
            sb.append(';');
        }

        if (sb.isEmpty()) {
            return null;
        }
        return "custom:" + stack.getType().getKey().getKey() + ":" + Integer.toHexString(sb.toString().hashCode());
    }
}
