package dev.recipeguide.gui;

import dev.recipeguide.RecipeGuidePlugin;
import dev.recipeguide.recipe.GuideRecipe;
import dev.recipeguide.recipe.GuideRecipe.Ingredient;
import dev.recipeguide.recipe.RecipeIndex;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * GUI de 54 slots con dos vistas: lista de recetas (para el item buscado) y detalle de una receta.
 * Click izquierdo en cualquier item = "dónde se usa"; click derecho = "cómo se craftea".
 */
public final class GuideGui implements InventoryHolder {

    public enum Mode { USES, PRODUCED_BY }

    private static final MiniMessage MM = MiniMessage.miniMessage();

    private static final int PER_PAGE = 45;
    private static final int SLOT_PREV = 45;
    private static final int SLOT_MODE = 46;
    private static final int SLOT_INFO = 48;
    private static final int SLOT_INPUT = 49;
    private static final int SLOT_NEXT = 53;

    private static final int SLOT_BACK = 49;
    private static final int SLOT_TYPE = 23;
    private static final int SLOT_RESULT = 25;

    private final RecipeGuidePlugin plugin;
    private final Inventory inventory;

    private ItemStack search;
    private Mode mode = Mode.USES;
    private int page;
    private List<GuideRecipe> current = List.of();
    private GuideRecipe viewing;

    public GuideGui(RecipeGuidePlugin plugin) {
        this.plugin = plugin;
        this.inventory = Bukkit.createInventory(this, 54, MM.deserialize("<dark_aqua>Guía de recetas"));
        showList();
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }

    public void open(Player player) {
        player.openInventory(inventory);
    }

    public void setSearch(ItemStack stack) {
        setSearch(stack, Mode.USES);
    }

    private void setSearch(ItemStack stack, Mode newMode) {
        search = stack.clone();
        search.setAmount(1);
        mode = newMode;
        page = 0;
        showList();
    }

    // ------------------------------------------------------------------ clicks

    public void handleClick(boolean topInventory, int slot, ItemStack clicked, ItemStack cursor, ClickType click) {
        Mode target = click.isRightClick() ? Mode.PRODUCED_BY : Mode.USES;

        if (!topInventory) {
            // click en el inventario del jugador: buscar ese item
            if (clicked != null && !clicked.isEmpty()) {
                setSearch(clicked, target);
            }
            return;
        }
        if (viewing != null) {
            handleRecipeClick(slot, target);
            return;
        }
        if (slot < PER_PAGE) {
            int index = page * PER_PAGE + slot;
            if (index < current.size()) {
                showRecipe(current.get(index));
            }
            return;
        }
        switch (slot) {
            case SLOT_PREV -> {
                if (page > 0) {
                    page--;
                    showList();
                }
            }
            case SLOT_NEXT -> {
                page++; // showList() lo limita a la última página
                showList();
            }
            case SLOT_MODE -> {
                mode = mode == Mode.USES ? Mode.PRODUCED_BY : Mode.USES;
                page = 0;
                showList();
            }
            case SLOT_INPUT -> {
                if (cursor != null && !cursor.isEmpty()) {
                    setSearch(cursor, mode);
                } else {
                    search = null;
                    page = 0;
                    showList();
                }
            }
            default -> {
            }
        }
    }

    private void handleRecipeClick(int slot, Mode target) {
        if (slot == SLOT_BACK) {
            showList();
            return;
        }
        if (slot == SLOT_RESULT) {
            setSearch(viewing.result(), target);
            return;
        }
        for (Map.Entry<Integer, Ingredient> entry : viewing.layout().entrySet()) {
            if (gridSlot(entry.getKey()) == slot) {
                setSearch(entry.getValue().options().get(0), target);
                return;
            }
        }
    }

    // ------------------------------------------------------------------ vistas

    private void showList() {
        viewing = null;
        fill();

        RecipeIndex index = plugin.index();
        if (search == null || index == null) {
            current = List.of();
        } else {
            current = mode == Mode.USES ? index.usesOf(search) : index.producersOf(search);
        }

        int pages = Math.max(1, (current.size() + PER_PAGE - 1) / PER_PAGE);
        page = Math.max(0, Math.min(page, pages - 1));

        for (int i = 0; i < PER_PAGE; i++) {
            int index2 = page * PER_PAGE + i;
            if (index2 >= current.size()) {
                inventory.setItem(i, null);
                continue;
            }
            GuideRecipe recipe = current.get(index2);
            inventory.setItem(i, display(recipe.result(), List.of(
                    line("<gray>" + recipe.type().label()),
                    line("<yellow>» Click: ver el crafteo"))));
        }

        if (page > 0) {
            inventory.setItem(SLOT_PREV, named(Material.ARROW, "<yellow>← Página anterior"));
        }
        if (page < pages - 1) {
            inventory.setItem(SLOT_NEXT, named(Material.ARROW, "<yellow>Página siguiente →"));
        }
        inventory.setItem(SLOT_MODE, named(Material.COMPARATOR,
                mode == Mode.USES ? "<aqua>Modo: dónde se usa" : "<aqua>Modo: cómo se craftea",
                "<gray>Click para cambiar de modo"));
        inventory.setItem(SLOT_INFO, named(Material.PAPER,
                "<gray>Página " + (page + 1) + "/" + pages + " · " + current.size() + " recetas"));

        if (search == null) {
            inventory.setItem(SLOT_INPUT, named(Material.HOPPER, "<green>Slot de búsqueda",
                    "<gray>Click con un item en el cursor,",
                    "<gray>o click en un item de tu inventario."));
        } else {
            inventory.setItem(SLOT_INPUT, display(search, List.of(
                    line("<gray>Click con la mano vacía: limpiar"))));
        }
    }

    private void showRecipe(GuideRecipe recipe) {
        viewing = recipe;
        fill();
        for (int i = 0; i < 9; i++) {
            inventory.setItem(gridSlot(i), null);
        }
        for (Map.Entry<Integer, Ingredient> entry : recipe.layout().entrySet()) {
            Ingredient ingredient = entry.getValue();
            List<Component> extra = new ArrayList<>();
            if (ingredient.options().size() > 1) {
                extra.add(line("<gray>(o cualquiera de " + ingredient.options().size() + " variantes)"));
            }
            extra.add(line("<yellow>Click izq: dónde se usa"));
            extra.add(line("<yellow>Click der: cómo se craftea"));
            inventory.setItem(gridSlot(entry.getKey()), display(ingredient.options().get(0), extra));
        }
        inventory.setItem(SLOT_TYPE, named(Material.ARROW, "<white>" + recipe.type().label()));
        inventory.setItem(SLOT_RESULT, display(recipe.result(), List.of(
                line("<yellow>Click izq: dónde se usa"),
                line("<yellow>Click der: cómo se craftea"))));
        inventory.setItem(SLOT_BACK, named(Material.BARRIER, "<red>Volver", "<gray>Regresar a la lista"));
    }

    // ------------------------------------------------------------------ helpers

    /** Cuadrícula 3x3 centrada: slots 10-12, 19-21, 28-30. */
    private static int gridSlot(int index) {
        return 10 + (index / 3) * 9 + (index % 3);
    }

    private void fill() {
        ItemStack filler = ItemStack.of(Material.GRAY_STAINED_GLASS_PANE);
        filler.editMeta(meta -> meta.displayName(Component.empty()));
        for (int i = 0; i < inventory.getSize(); i++) {
            inventory.setItem(i, filler);
        }
    }

    private static Component line(String mini) {
        return MM.deserialize("<!italic>" + mini);
    }

    private static ItemStack named(Material material, String name, String... lore) {
        ItemStack stack = ItemStack.of(material);
        stack.editMeta(meta -> {
            meta.displayName(line(name));
            if (lore.length > 0) {
                List<Component> lines = new ArrayList<>();
                for (String text : lore) {
                    lines.add(line(text));
                }
                meta.lore(lines);
            }
        });
        return stack;
    }

    /** Copia del item (con su textura/nombre custom intactos) + líneas extra de lore. */
    private static ItemStack display(ItemStack base, List<Component> extraLore) {
        ItemStack copy = base.clone();
        copy.editMeta(meta -> {
            List<Component> lore = meta.lore() == null ? new ArrayList<>() : new ArrayList<>(meta.lore());
            lore.addAll(extraLore);
            meta.lore(lore);
        });
        return copy;
    }
}
