package dev.recipeguide.gui;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;

public final class GuideListener implements Listener {

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        Inventory top = event.getView().getTopInventory();
        if (!(top.getHolder() instanceof GuideGui gui)) {
            return;
        }
        event.setCancelled(true); // nadie se lleva items de la guía
        if (!(event.getWhoClicked() instanceof Player)) {
            return;
        }
        Inventory clickedInventory = event.getClickedInventory();
        if (clickedInventory == null) {
            return;
        }
        boolean isTop = clickedInventory.equals(top);
        gui.handleClick(isTop, event.getSlot(), event.getCurrentItem(), event.getCursor(), event.getClick());
    }

    @EventHandler
    public void onDrag(InventoryDragEvent event) {
        if (event.getView().getTopInventory().getHolder() instanceof GuideGui) {
            event.setCancelled(true);
        }
    }
}
