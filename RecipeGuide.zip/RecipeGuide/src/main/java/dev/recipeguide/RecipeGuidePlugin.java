package dev.recipeguide;

import dev.recipeguide.gui.GuideGui;
import dev.recipeguide.gui.GuideListener;
import dev.recipeguide.item.FingerprintProvider;
import dev.recipeguide.item.ItemResolver;
import dev.recipeguide.item.PdcIdProvider;
import dev.recipeguide.item.ReflectiveProvider;
import dev.recipeguide.recipe.RecipeIndex;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.server.ServerLoadEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

public final class RecipeGuidePlugin extends JavaPlugin implements Listener, CommandExecutor {

    private static final MiniMessage MM = MiniMessage.miniMessage();

    private ItemResolver resolver;
    private RecipeIndex index;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        setupResolver();

        getServer().getPluginManager().registerEvents(this, this);
        getServer().getPluginManager().registerEvents(new GuideListener(), this);

        if (getCommand("guia") != null) {
            getCommand("guia").setExecutor(this);
        }

        // Índice inicial al siguiente tick; se reconstruye otra vez cuando el servidor termina
        // de cargar (así entran las recetas que otros plugins registran tarde).
        getServer().getScheduler().runTask(this, this::rebuild);
    }

    public RecipeIndex index() {
        return index;
    }

    @EventHandler
    public void onServerLoad(ServerLoadEvent event) {
        rebuild();
    }

    private void setupResolver() {
        resolver = new ItemResolver();

        // Orden importa: primero las APIs específicas, al final el fallback genérico.
        resolver.add(new ReflectiveProvider(getLogger(), "oraxen", "Oraxen",
                "io.th0rgal.oraxen.api.OraxenItems", "getIdByItem"));
        resolver.add(new ReflectiveProvider(getLogger(), "nexo", "Nexo",
                "com.nexomc.nexo.api.NexoItems", "idFromItem"));
        resolver.add(new ReflectiveProvider(getLogger(), "craftengine", "CraftEngine",
                "net.momirealms.craftengine.bukkit.api.CraftEngineItems", "getCustomItemId"));

        resolver.add(new PdcIdProvider(getConfig().getStringList("pdc-id-keys")));
        if (getConfig().getBoolean("generic-fingerprint", true)) {
            resolver.add(new FingerprintProvider());
        }
    }

    private void rebuild() {
        index = new RecipeIndex(resolver, getConfig().getBoolean("material-choice-matches-custom", false));
        index.rebuild();
        getLogger().info("Guía de recetas lista: " + index.recipeCount() + " recetas indexadas.");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length > 0 && args[0].equalsIgnoreCase("recargar")) {
            if (!sender.hasPermission("recipeguide.admin")) {
                sender.sendMessage(MM.deserialize("<red>No tienes permiso."));
                return true;
            }
            reloadConfig();
            setupResolver();
            rebuild();
            sender.sendMessage(MM.deserialize("<green>Guía recargada: " + index.recipeCount() + " recetas."));
            return true;
        }

        if (!(sender instanceof Player player)) {
            sender.sendMessage("Solo jugadores pueden abrir la guía.");
            return true;
        }
        if (index == null) {
            player.sendMessage(MM.deserialize("<yellow>La guía aún se está cargando, intenta de nuevo."));
            return true;
        }

        GuideGui gui = new GuideGui(this);
        ItemStack hand = player.getInventory().getItemInMainHand();
        if (!hand.isEmpty()) {
            gui.setSearch(hand); // si llevas un item en la mano, ya viene buscado
        }
        gui.open(player);
        return true;
    }
}
