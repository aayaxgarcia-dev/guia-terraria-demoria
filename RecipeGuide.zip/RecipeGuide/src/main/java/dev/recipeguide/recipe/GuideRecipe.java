package dev.recipeguide.recipe;

import org.bukkit.inventory.ItemStack;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Una receta lista para mostrar. {@code layout} mapea posiciones de una cuadrícula 3x3
 * (0-8, de izquierda a derecha y de arriba a abajo) a su ingrediente.
 */
public record GuideRecipe(String id, Type type, ItemStack result, Map<Integer, Ingredient> layout) {

    public enum Type {
        SHAPED("Crafteo con forma"),
        SHAPELESS("Crafteo sin forma"),
        COOKING("Horno / cocción"),
        SMITHING("Mesa de herrería"),
        STONECUTTING("Cortapiedras");

        private final String label;

        Type(String label) {
            this.label = label;
        }

        public String label() {
            return label;
        }
    }

    /** Opciones que acepta una casilla y sus claves de identidad ya resueltas. */
    public record Ingredient(List<ItemStack> options, Set<String> keys) {
    }

    @Override
    public boolean equals(Object other) {
        return other instanceof GuideRecipe r && r.id.equals(id);
    }

    @Override
    public int hashCode() {
        return id.hashCode();
    }
}
