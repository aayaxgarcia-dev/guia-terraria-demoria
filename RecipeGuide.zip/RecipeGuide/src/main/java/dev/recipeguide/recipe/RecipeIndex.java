package dev.recipeguide.recipe;

import dev.recipeguide.item.ItemResolver;
import dev.recipeguide.recipe.GuideRecipe.Ingredient;
import org.bukkit.Bukkit;
import org.bukkit.Keyed;
import org.bukkit.Material;
import org.bukkit.inventory.CookingRecipe;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.Recipe;
import org.bukkit.inventory.RecipeChoice;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.ShapelessRecipe;
import org.bukkit.inventory.SmithingTransformRecipe;
import org.bukkit.inventory.SmithingTrimRecipe;
import org.bukkit.inventory.StonecuttingRecipe;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Índice en memoria: identidad del item -> recetas donde se usa / recetas que lo producen. */
public final class RecipeIndex {

    private final ItemResolver resolver;
    private final boolean materialChoiceMatchesCustom;

    private Map<String, List<GuideRecipe>> uses = Map.of();
    private Map<String, List<GuideRecipe>> producers = Map.of();
    private int recipeCount;

    public RecipeIndex(ItemResolver resolver, boolean materialChoiceMatchesCustom) {
        this.resolver = resolver;
        this.materialChoiceMatchesCustom = materialChoiceMatchesCustom;
    }

    public int recipeCount() {
        return recipeCount;
    }

    /** Debe llamarse en el hilo principal. */
    public void rebuild() {
        Map<String, List<GuideRecipe>> newUses = new HashMap<>();
        Map<String, List<GuideRecipe>> newProducers = new HashMap<>();
        int count = 0;

        Iterator<Recipe> iterator = Bukkit.recipeIterator();
        while (iterator.hasNext()) {
            GuideRecipe guide;
            try {
                guide = convert(iterator.next());
            } catch (Throwable t) {
                continue; // receta rara: se omite
            }
            if (guide == null) {
                continue;
            }
            count++;

            String resultKey = resolver.resolve(guide.result());
            if (resultKey != null) {
                newProducers.computeIfAbsent(resultKey, k -> new ArrayList<>()).add(guide);
            }
            Set<String> seen = new HashSet<>();
            for (Ingredient ingredient : guide.layout().values()) {
                for (String key : ingredient.keys()) {
                    if (seen.add(key)) {
                        newUses.computeIfAbsent(key, k -> new ArrayList<>()).add(guide);
                    }
                }
            }
        }
        this.uses = newUses;
        this.producers = newProducers;
        this.recipeCount = count;
    }

    /** Recetas donde este item es ingrediente. */
    public List<GuideRecipe> usesOf(ItemStack stack) {
        String key = resolver.resolve(stack);
        if (key == null) {
            return List.of();
        }
        Set<GuideRecipe> out = new LinkedHashSet<>(uses.getOrDefault(key, List.of()));
        if (materialChoiceMatchesCustom && ItemResolver.isCustom(key)) {
            out.addAll(uses.getOrDefault(stack.getType().getKey().toString(), List.of()));
        }
        return new ArrayList<>(out);
    }

    /** Recetas que producen este item. */
    public List<GuideRecipe> producersOf(ItemStack stack) {
        String key = resolver.resolve(stack);
        if (key == null) {
            return List.of();
        }
        return new ArrayList<>(producers.getOrDefault(key, List.of()));
    }

    private GuideRecipe convert(Recipe recipe) {
        ItemStack result = recipe.getResult();
        if (result == null || result.getType().isAir()) {
            return null;
        }
        String id = recipe instanceof Keyed keyed ? keyed.getKey().toString() : "unknown:" + System.identityHashCode(recipe);
        Map<Integer, Ingredient> layout = new LinkedHashMap<>();
        GuideRecipe.Type type;

        if (recipe instanceof ShapedRecipe shaped) {
            type = GuideRecipe.Type.SHAPED;
            String[] shape = shaped.getShape();
            Map<Character, RecipeChoice> choices = shaped.getChoiceMap();
            for (int row = 0; row < shape.length; row++) {
                for (int col = 0; col < shape[row].length(); col++) {
                    put(layout, row * 3 + col, choices.get(shape[row].charAt(col)));
                }
            }
        } else if (recipe instanceof ShapelessRecipe shapeless) {
            type = GuideRecipe.Type.SHAPELESS;
            int slot = 0;
            for (RecipeChoice choice : shapeless.getChoiceList()) {
                if (slot > 8) {
                    break;
                }
                if (put(layout, slot, choice)) {
                    slot++;
                }
            }
        } else if (recipe instanceof CookingRecipe<?> cooking) {
            type = GuideRecipe.Type.COOKING;
            put(layout, 4, cooking.getInputChoice());
        } else if (recipe instanceof SmithingTransformRecipe transform) {
            type = GuideRecipe.Type.SMITHING;
            put(layout, 3, transform.getTemplate());
            put(layout, 4, transform.getBase());
            put(layout, 5, transform.getAddition());
        } else if (recipe instanceof SmithingTrimRecipe trim) {
            type = GuideRecipe.Type.SMITHING;
            put(layout, 3, trim.getTemplate());
            put(layout, 4, trim.getBase());
            put(layout, 5, trim.getAddition());
        } else if (recipe instanceof StonecuttingRecipe stonecutting) {
            type = GuideRecipe.Type.STONECUTTING;
            put(layout, 4, stonecutting.getInputChoice());
        } else {
            return null;
        }

        if (layout.isEmpty()) {
            return null;
        }
        return new GuideRecipe(id, type, result.clone(), layout);
    }

    private boolean put(Map<Integer, Ingredient> layout, int slot, RecipeChoice choice) {
        Ingredient ingredient = toIngredient(choice);
        if (ingredient == null) {
            return false;
        }
        layout.put(slot, ingredient);
        return true;
    }

    private Ingredient toIngredient(RecipeChoice choice) {
        if (choice == null) {
            return null;
        }
        List<ItemStack> options = new ArrayList<>();
        Set<String> keys = new LinkedHashSet<>();

        if (choice instanceof RecipeChoice.MaterialChoice materialChoice) {
            // Material puro: solo coincide con items "limpios" (clave minecraft:...)
            for (Material material : materialChoice.getChoices()) {
                if (material.isAir()) {
                    continue;
                }
                options.add(ItemStack.of(material));
                keys.add(material.getKey().toString());
            }
        } else if (choice instanceof RecipeChoice.ExactChoice exactChoice) {
            // Item exacto: aquí viven las recetas de Oraxen, Nexo, CraftEngine, etc.
            for (ItemStack stack : exactChoice.getChoices()) {
                String key = resolver.resolve(stack);
                if (key == null) {
                    continue;
                }
                options.add(stack.clone());
                keys.add(key);
            }
        }

        if (options.isEmpty()) {
            return null;
        }
        return new Ingredient(options, keys);
    }
}
